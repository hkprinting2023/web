<?php
return [
  'host' => 'localhost',
  'dbname' => 'hk_printing',
  'user' => 'root',
  'pass' => '',
  'charset' => 'utf8mb4'
];
