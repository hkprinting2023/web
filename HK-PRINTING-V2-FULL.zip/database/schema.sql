CREATE DATABASE IF NOT EXISTS hk_printing CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hk_printing;
CREATE TABLE users(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(120) NOT NULL,email VARCHAR(190) UNIQUE NOT NULL,password VARCHAR(255) NOT NULL,role ENUM('customer','admin') DEFAULT 'customer',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE categories(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(120) NOT NULL);
CREATE TABLE products(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(190) NOT NULL,sku VARCHAR(80),price DECIMAL(14,2) NOT NULL,stock INT DEFAULT 0,category_id INT,description TEXT,image VARCHAR(255),active TINYINT DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE SET NULL);
CREATE TABLE orders(id INT AUTO_INCREMENT PRIMARY KEY,order_no VARCHAR(40) UNIQUE,user_id INT,total DECIMAL(14,2),status VARCHAR(30) DEFAULT 'pending',customer_name VARCHAR(120),phone VARCHAR(40),address TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE TABLE order_items(id INT AUTO_INCREMENT PRIMARY KEY,order_id INT,product_id INT,qty INT,price DECIMAL(14,2),FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE RESTRICT);
INSERT INTO categories(name) VALUES ('ATK'),('Peralatan Sekolah'),('Cetak Foto'),('Banner'),('Undangan'),('Dokumen');
INSERT INTO users(name,email,password,role) VALUES ('Administrator','admin@hkprinting.local','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC2p3z8nZ4Z4Hqf5hQW6','admin');
INSERT INTO products(name,sku,price,stock,category_id,description,image,active) VALUES
('Contoh Produk ATK','ATK001',5000,100,1,'Produk contoh HK Printing','assets/placeholder.svg',1),
('Cetak Foto 4x6','FOTO46',3000,999,3,'Cetak foto ukuran 4x6','assets/placeholder.svg',1);
