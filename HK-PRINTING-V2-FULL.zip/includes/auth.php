<?php
require_once __DIR__.'/db.php';
function e($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function user(){global $pdo; if(empty($_SESSION['uid'])) return null; static $u=null; if($u===null){$q=$pdo->prepare("SELECT * FROM users WHERE id=?");$q->execute([$_SESSION['uid']]);$u=$q->fetch();} return $u;}
function admin(){return user() && user()['role']==='admin';}
function require_login(){if(!user()){header('Location: login.php');exit;}}
function require_admin(){if(!admin()){header('Location: login.php');exit;}}
function rupiah($n){return 'Rp '.number_format($n,0,',','.');}
function wa_number(){return '6282234344658';}
